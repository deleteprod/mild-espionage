# ADS-B CSV Cleaner

A self-contained Docker service that accepts raw ADS-B SBS-format CSV files
via HTTP POST, validates them, consolidates the fragmented per-message rows
into one complete row per aircraft observation window, and returns a
downloadable cleaned CSV.

---

## Quick start

```bash
# Build and start
docker compose up --build -d

# Check it's running
curl http://localhost:8000/health
# → {"status":"ok"}
```

---

## API

### POST /upload

Upload a raw ADS-B CSV file.  The file must be sent as `multipart/form-data`
with the field name `file`.

**curl example**
```bash
curl -X POST http://localhost:8000/upload \
     -F "file=@/path/to/raw_adsb.csv"
```

**Success response – 200 OK**
```json
{
  "download_url":             "/download/a3f8c1d2e4b5...",
  "processing_time_seconds":  42.7,
  "output_rows":              198432
}
```

**Error responses**

| Status | Meaning |
|--------|---------|
| 400    | Empty file |
| 413    | File exceeds 10 GB limit |
| 422    | Validation failed (body contains details) |
| 500    | Internal processing error |

---

### GET /download/{id}

Download the cleaned CSV produced by a previous `/upload` call.
Use the `download_url` value from the upload response.

```bash
curl http://localhost:8000/download/a3f8c1d2e4b5... \
     -o cleaned_adsb.csv
```

---

## Validation rules

The service checks the following before processing:

| Field | Column | Rule |
|-------|--------|------|
| ICAO hex | 5 | Exactly 6 hexadecimal characters |
| Altitude | 12 | Numeric |
| Speed | 13 | Numeric, ≥ 0 |
| Heading | 14 | 0 – 359.9 |
| Latitude | 15 | Contains decimal point, −90 to 90 |
| Longitude | 16 | Contains decimal point, −180 to 180 |
| Squawk | 18 | Exactly 4 digits |

95 % of populated cells in each column must pass their rule.  The threshold
is intentionally not 100 % to tolerate occasional corrupt or missing values
in real-world ADS-B feeds.

---

## Output columns

```
icao_hex, date, time, callsign, altitude, speed, heading,
latitude, longitude, vertical_speed, squawk
```

---

## File retention

Cleaned output files are stored in the `adsb_outputs` Docker volume
indefinitely.  If you want automatic clean-up, add a cron job or a
simple scheduled task that deletes files older than N days:

```bash
# Delete output files older than 7 days (run on the host)
docker exec adsb-cleaner find /data/outputs -mtime +7 -delete
```

---

## Scaling

The container runs a single Uvicorn worker because pandas CSV processing is
CPU-bound.  To handle concurrent uploads, run multiple containers behind a
reverse proxy (e.g. nginx or Caddy):

```bash
docker compose up --scale adsb-cleaner=4 -d
```
